require("./bootstrap");

require("alpinejs");
