<button <?php echo e($attributes->merge(['type' => 'submit', 'class' => 'btn'])); ?>>
    <?php echo e($slot); ?>

</button>
<?php /**PATH D:\laragon\www\lara_cms\resources\views/components/button.blade.php ENDPATH**/ ?>