<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">

  <!-- CSRF Token -->
  <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

  <title><?php if($webSettings): ?> <?php echo e($webSettings->site_title); ?> <?php else: ?> <?php echo e(config('app.name', 'Laravel')); ?> <?php endif; ?></title>

  <!-- Fonts -->
  <link rel="dns-prefetch" href="//fonts.gstatic.com">
  <link href="https://fonts.googleapis.com/css?family=Nunito" rel="stylesheet">

  <!-- Bootstrap -->
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/css/bootstrap.min.css"
    integrity="sha384-zCbKRCUGaJDkqS1kPbPd7TveP5iyJE0EjAuZQTgFLD2ylzuqKfdKlfG/eSrtxUkn" crossorigin="anonymous">
  <!-- App Styles -->
  <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
  <?php echo $__env->yieldContent('head_styles'); ?>

</head>

<body>
  <div id="app">
    <?php echo $__env->make('layouts.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <main class="py-4">
      <div class="container">
        <?php echo e($slot); ?>

      </div>
    </main>
  </div>


  <!-- jQuery -->
  <script src="https://cdn.jsdelivr.net/npm/jquery@3.5.1/dist/jquery.min.js"
    integrity="sha256-9/aliU8dGd2tb6OSsuzixeV4y/faTqgFtohetphbbj0=" crossorigin="anonymous"></script>
  <!-- Bootstrap -->
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/js/bootstrap.bundle.min.js"
    integrity="sha384-fQybjgWLrvvRgtW6bFlB7jaZrFsaBXjsOMm/tB9LTS58ONXgqbR9W8oWht/amnpF" crossorigin="anonymous">
  </script>

  <!-- App Scripts -->
  <script src="<?php echo e(asset('js/app.js')); ?>" defer></script>
  <?php echo $__env->yieldPushContent('bottom_scripts'); ?>
</body>

</html><?php /**PATH D:\laragon\www\lara_cms\resources\views/layouts/app.blade.php ENDPATH**/ ?>