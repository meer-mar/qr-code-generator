<footer class="main-footer">
  <strong>Copyright &copy; 2021 <a href="#">CMS</a>.</strong>
  All rights reserved.
  <div class="float-right d-none d-sm-inline-block">
    <b>Version</b> 1.0
  </div>
</footer><?php /**PATH D:\laragon\www\lara_cms\resources\views/dashboard/admin/includes/footer.blade.php ENDPATH**/ ?>