<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header"><?php echo e($header); ?></div>

                <div class="card-body">
                    <?php echo e($slot); ?>

                </div>
            </div>
        </div>
    </div>
</div>
<?php /**PATH D:\laragon\www\lara_cms\resources\views/components/auth-card.blade.php ENDPATH**/ ?>