<?php return array (
  'admin.user.show-user' => 'App\\Http\\Livewire\\Admin\\User\\ShowUser',
);