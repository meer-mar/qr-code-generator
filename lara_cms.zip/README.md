## CMS Boilerplate

## Admin Credentials

<p>
email : admin@admin.com<br>
password : admin
</p>

## Test User Credentials

<p>
email : johnconnor2996@gmail.com<br>
password : password
</p>

## Step 1

<p>Disable code inside AppServiceProvider file boot method code</p>

## Step 2

<p>Run command: composer install</p>

## Step 3

<p>Run command: cp .env.example .env</p>

## Step 4

<p>Set db credentails in env file</p>

## Step 5

<p>Run command : php artisan key:generate</p>

## Step 6

<p>Run command : php artisan migrate:fresh --seed</p>

## Step 7

<p>Run command : npm install</p>

## Step 8

<p>Run command : npm run dev</p>

## Step 9

<p>Enable code inside AppServiceProvider file boot method code</p>
