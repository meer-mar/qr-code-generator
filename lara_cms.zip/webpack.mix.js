const mix = require("laravel-mix");

/*
 |--------------------------------------------------------------------------
 | Mix Asset Management
 |--------------------------------------------------------------------------
 |
 | Mix provides a clean, fluent API for defining some Webpack build steps
 | for your Laravel applications. By default, we are compiling the CSS
 | file for the application as well as bundling up all the JS files.
|
 */

mix.js("resources/js/app.js", "public/admin_dashboard/assets/js")
    .js("resources/js/front_app.js", "public/js/app.js")
    .sass("resources/sass/app.scss", "public/admin_dashboard/assets/css")
    .sass("resources/sass/front_app.scss", "public/css/app.css")
    .sourceMaps();
